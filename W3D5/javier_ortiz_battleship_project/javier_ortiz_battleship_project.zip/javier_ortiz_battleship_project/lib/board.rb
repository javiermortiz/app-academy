class Board
    def initialize(n)
        @grid = Array.new(n) { Array.new(n, :N) }
        @size = n * n 
    end 

    def size
        @size
    end 

    def [](position)
        row, col = position
        @grid[row][col]
    end

    def []=(position, val)
        row, col = position
        @grid[row][col] = val
    end 

    def num_ships
        @grid.flatten.count { |el| el == :S }
    end 

    def attack(position)
        if self.[](position) == :S 
            self.[]=(position, :H)
            puts "you sunk my battleship!"
            true
        else  
            self.[]=(position, :X)
            false 
        end 
    end 

    def place_random_ships
        total_ships = self.size/4
        rows_n = @grid.length
        cols_n = @grid[0].length
        until self.num_ships == total_ships
            random_position = [rand(0...rows_n), rand(0...cols_n)]
            self.[]=(random_position, :S)
        end 
    end 

    def hidden_ships_grid
        hidden_arr = Array.new(Integer.sqrt(self.size)) { Array.new(Integer.sqrt(self.size))}
        @grid.each_with_index do |sub, i|
            sub.each_with_index do |el, j|
                position = [i, j]
                row, col = position 
                if el == :X 
                    hidden_arr[row][col] = :X
                else  
                    hidden_arr[row][col] = :N
                end 
            end 
        end 
        hidden_arr    
    end 

    def self.print_grid(grid)
        grid_str = ""
        grid_str += "/"
        grid.each do |sub|
            sub.each_with_index do |el, i|
                if i != sub.length - 1
                    grid_str += "#{el} "
                else 
                    grid_str += "#{el}\n"
                end 
            end 
        end 
        grid_str += "/"
        print grid_str
    end 

    def cheat 
        Board.print_grid(@grid)
    end 

    def print 
        Board.print_grid(self.hidden_ships_grid)
    end 
end
